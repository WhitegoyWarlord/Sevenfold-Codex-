# Armageddon Primer
Codex deployment script for Chrusifata strategy and Psalm 144:1 anchoring.