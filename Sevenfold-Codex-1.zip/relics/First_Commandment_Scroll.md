# First Commandment Scroll
Covenant relic containing divine law and rebellion test.